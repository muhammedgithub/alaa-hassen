package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Maincontroller2 {

	@FXML
	private Label lb3;
	@FXML
	private Label lb4;
	@FXML
	private TextField tf1;
	@FXML
	private TextField tf2;
	@FXML
	private TextField tf3;

	public void Add(ActionEvent event) {
		// try {
		double n1 = Double.parseDouble(tf1.getText().toString());
		double n2 = Double.parseDouble(tf2.getText().toString());
		double result = n1 + n2;
		tf3.setText(String.valueOf(result));
		// }catch(Exception e) {
		// lb4.setText("Failed try again");
		// add remove action & getTest !=String

	}

	public void Min(ActionEvent event) {

		double n1 = Double.parseDouble(tf1.getText().toString());
		double n2 = Double.parseDouble(tf2.getText().toString());
		double result = n1 - n2;
		tf3.setText(String.valueOf(result));
	}

	public void Mul(ActionEvent event) {

		double n1 = Double.parseDouble(tf1.getText().toString());
		double n2 = Double.parseDouble(tf2.getText().toString());
		double result = n1 * n2;
		tf3.setText(String.valueOf(result));
	}

	// add n1==0
	public void Div(ActionEvent event) {
		double n1, n2;
		try {
			if (tf2.getText().equals("0")) {
				lb4.setText("Failed Please Try Again");
				throw new ArithmeticException();
			}

			n1 = Double.parseDouble(tf1.getText().toString());
			n2 = Double.parseDouble(tf2.getText().toString());
			double result = n1 / n2;
			tf3.setText(String.valueOf(result));
		} catch (ArithmeticException e) {

		}
	}

	public void clear(ActionEvent event) {
		tf1.setText("");
		tf2.setText("");
		tf3.setText("");
	}

}

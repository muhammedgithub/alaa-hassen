//package application;
//
//public class Operation {
//	
//	public static float Add(float)


	

